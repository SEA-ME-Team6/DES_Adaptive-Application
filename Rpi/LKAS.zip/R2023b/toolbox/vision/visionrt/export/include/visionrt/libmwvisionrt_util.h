#ifndef libmwvisionrt_util_h
#define libmwvisionrt_util_h
 
  /* All symbols in this module are intentionally exported. */
  #ifdef _MSC_VER
      #define LIBMWVISIONRT_API __declspec(dllexport)
  #else
      #define LIBMWVISIONRT_API
  #endif

#endif
